stamp="""
Developed by...
  _ _ __ __ _ _ ____   _ _ _ _ __ __ _ _
 | | | _|  \ \ |  __| | | | | | _|  \ \ |
 |  / _| ()|   | |_ | |   |  / _| ()|   |  _
|__/____|__/_|_|____| |_|_/_/____|__/_|_| (_)
"""

def print_stamp():
    print(stamp)
    print("https://github.com/YeongHyeon/CNN_Own_Dataset")
